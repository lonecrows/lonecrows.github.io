Source code for the platform and components is available from PortableApps.com under the GPL (full license in Other\Source)

Certain components have additional licensing which is included alongside their binaries or within the Other\Source directory

The PortableApps.com Logo and themes are trade dress of Rare Ideas, LLC.  No permission to use or modify them is expressed or implied.